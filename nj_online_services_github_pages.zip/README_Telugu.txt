NJ ONLINE SERVICES - GitHub Pages Setup

1. Download and extract this ZIP file.
2. Open your GitHub repository.
3. Choose Add file > Upload files.
4. Upload index.html to the repository root (top level).
5. Commit changes.
6. Open Settings > Pages.
7. Under Build and deployment, choose Deploy from a branch.
8. Choose branch main and folder /(root), then Save.
9. Wait a few minutes and open https://YOUR-USERNAME.github.io

Before publishing:
- Replace placeholder contact details with your business WhatsApp number and email.
- Add your real Google Maps link when your business address is confirmed.
- Update the service charges with your actual charges.
- Add only genuine customer reviews with permission.
- Never publish passwords, OTPs, ATM PINs, card details or customer personal data.
- This static site does not process payments or bookings automatically.
